#include <stdint.h>

#include "state_settings_JWatch.h"

#include "receiver.h"
#include "channels.h"

#include "settings.h"
#include "settings_internal.h"
#include "settings_eeprom.h"
#include "buttons.h"

#include "ui.h"
#include "pstr_helper.h"


void StateMachine::SettingsJWatchStateHandler::onEnter() {
    internalState = InternalState::ENABLE;
}



void StateMachine::SettingsJWatchStateHandler::onButtonChange(
    Button button,
    Buttons::PressType pressType
) {
    if (button == Button::MODE ){
       

    switch (internalState) {
        case InternalState::ENABLE:
            internalState = InternalState::STRENGTH;
            break;

        case InternalState::STRENGTH:
            internalState = InternalState::STRENGTH2;
            break;

             case InternalState::STRENGTH2:
            internalState = InternalState::DONE;
            break;
            
        case InternalState::DONE:
            EepromSettings.save();
            StateMachine::switchState(StateMachine::State::MENU);
        break;
    }
    }
    else if (button == Button::UP ){
      if (internalState == InternalState::ENABLE){
        if (EepromSettings.searchJWatch == true){
          EepromSettings.searchJWatch = false;
        }else{
          EepromSettings.searchJWatch = true;
        }
      }
      if (internalState == InternalState::STRENGTH && EepromSettings.searchJWatchStrength <= 99){
        holderStrength = EepromSettings.searchJWatchStrength;
        EepromSettings.searchJWatchStrength = holderStrength + 1;
      }
      if (internalState == InternalState::STRENGTH2 && EepromSettings.searchJWatchStrengthTrigger <= 99){
        holderStrengthT = EepromSettings.searchJWatchStrengthTrigger;
        EepromSettings.searchJWatchStrengthTrigger = holderStrengthT + 1;
      }}
      if (button == Button::DOWN ){
      if (internalState == InternalState::ENABLE){
        if (EepromSettings.searchJWatch == true){
          EepromSettings.searchJWatch = false;
        }else{
          EepromSettings.searchJWatch = true;
        }
      }
      if (internalState == InternalState::STRENGTH && EepromSettings.searchJWatchStrength > 0){
        holderStrength = EepromSettings.searchJWatchStrength;
        EepromSettings.searchJWatchStrength = holderStrength - 1;
      }
      if (internalState == InternalState::STRENGTH2 && EepromSettings.searchJWatchStrengthTrigger > 0){
        holderStrengthT = EepromSettings.searchJWatchStrengthTrigger;
        EepromSettings.searchJWatchStrengthTrigger = holderStrengthT - 1;
      }
    }
    Ui::needUpdate();
}


void StateMachine::SettingsJWatchStateHandler::onInitialDraw() {
    Ui::needUpdate(); // Lazy. :(
}

void StateMachine::SettingsJWatchStateHandler::onUpdateDraw() {
    Ui::clear();

    switch (internalState) {
        case InternalState::ENABLE:
            Ui::display.setTextSize(1);
            Ui::display.setCursor(0, 0);
            Ui::display.print(PSTR2("1/4\nEnable Bird Watch?"));
            Ui::display.setCursor(0, (CHAR_HEIGHT + 1) * 2);
            if (EepromSettings.searchJWatch == true){
            Ui::display.print(PSTR2("Enabled"));}
            else{
            Ui::display.print(PSTR2("Disabled"));
            }
            Ui::display.print(PSTR2("\nSignified by a ! next\nto frequency"));
              
            
            Ui::display.setCursor(0, SCREEN_HEIGHT - CHAR_HEIGHT - 1);
            Ui::display.print(PSTR2("Press MODE for next."));
        break;

        case InternalState::STRENGTH:
            Ui::display.setTextSize(1);
            Ui::display.setCursor(0, 0);
            Ui::display.print(PSTR2("2/4\nSwitch Strength\n"));
            Ui::display.print(EepromSettings.searchJWatchStrength);
             Ui::display.print(PSTR2("% RSSI"));
            Ui::display.print(PSTR2("\nDecides when to change\nchannels"));
            Ui::display.setCursor(0, SCREEN_HEIGHT - CHAR_HEIGHT - 1);
            Ui::display.print(PSTR2("Press MODE for next."));
        break;

        case InternalState::STRENGTH2:
            Ui::display.setTextSize(1);
            Ui::display.setCursor(0, 0);
            Ui::display.print(PSTR2("3/4\nSelection Strength\n"));
            Ui::display.print(EepromSettings.searchJWatchStrengthTrigger);
            Ui::display.print(PSTR2("% RSSI"));
            Ui::display.print(PSTR2("\nDecides when to stop\nscanning\n"));
            Ui::display.setCursor(0, SCREEN_HEIGHT - CHAR_HEIGHT - 1);
            Ui::display.print(PSTR2("Press MODE to Save."));
        break;
        
        case InternalState::DONE:
            Ui::display.setTextSize(1);
            Ui::display.setCursor(0, 0);
            Ui::display.print(PSTR2("3/4\nSaved settings!"));
            Ui::display.print(PSTR2("\n\nDesigned by BluJ!"));
            Ui::display.setCursor(0, SCREEN_HEIGHT - CHAR_HEIGHT - 1);
            Ui::display.print(PSTR2("Press MODE to Exit."));

         
        break;

        
    }

    Ui::needDisplay();
}

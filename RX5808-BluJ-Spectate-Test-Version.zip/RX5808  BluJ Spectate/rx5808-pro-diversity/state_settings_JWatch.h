#ifndef STATE_SETTINGS_JWatch_H
#define STATE_SETTINGS_JWatch_H


#include "state.h"


namespace StateMachine {
    class SettingsJWatchStateHandler : public StateMachine::StateHandler {
        private:
            enum class InternalState : uint8_t {
                ENABLE,
                STRENGTH,
                STRENGTH2,
                DONE
            };


            InternalState internalState = InternalState::ENABLE;
            uint8_t rssiStrength = 0;
            uint8_t holderStrength = 30;
            uint8_t holderStrengthT = 75;


        public:
            void onEnter();
            //void onUpdate();

            void onInitialDraw();
            void onUpdateDraw();

            void onButtonChange(Button button, Buttons::PressType pressType);
    };
}


#endif
